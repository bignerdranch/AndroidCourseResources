package com.bignerdranch.android.photogallery;

public class Constants {

    public static final String API_KEY = "4f721bbafa75bf6d2cb5af54f937bb70";
    public static final String ENDPOINT = "http://api.flickr.com/services/rest/";
    public static final String METHOD_GET_RECENT = "flickr.photos.getRecent";
    public static final String EXTRA_SMALL_URL = "url_s";
    public static final String PARAM_EXTRAS = "extras";

}
