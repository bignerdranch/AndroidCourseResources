package com.bignerdranch.android.photogallery;

import java.io.IOException;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.net.Uri;

import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;

public class GalleryItemRequest extends XmlPullParsingRequest<ArrayList<GalleryItem>> {
    public static GalleryItemRequest newRecentItemsRequest(ErrorListener errorListener, Listener<ArrayList<GalleryItem>> listener) {
        String url = Uri.parse(Constants.ENDPOINT).buildUpon()
                .appendQueryParameter("method", Constants.METHOD_GET_RECENT)
                .appendQueryParameter("api_key", Constants.API_KEY)
                .appendQueryParameter(Constants.PARAM_EXTRAS, Constants.EXTRA_SMALL_URL)
                .build().toString();
        return new GalleryItemRequest(Method.GET, url, errorListener, listener);
    }

    public GalleryItemRequest(int method, String url, ErrorListener errorListener, Listener<ArrayList<GalleryItem>> listener) {
        super(method, url, errorListener, listener);
    }

    @Override
    public ArrayList<GalleryItem> parseXml(XmlPullParser parser) throws IOException, XmlPullParserException {
        ArrayList<GalleryItem> items = new ArrayList<GalleryItem>();

        int eventType = parser.next();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG &&
                "photo".equals(parser.getName())) {
                String id = parser.getAttributeValue(null, "id");
                String caption = parser.getAttributeValue(null, "title");
                String smallUrl = parser.getAttributeValue(null,  "url_s");

                GalleryItem item = new GalleryItem();
                item.setId(id);
                item.setCaption(caption);
                item.setUrl(smallUrl);
                items.add(item);
            }

            eventType = parser.next();
        }
        
        return items;
    }
}
