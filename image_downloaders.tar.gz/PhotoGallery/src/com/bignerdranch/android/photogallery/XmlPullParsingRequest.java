package com.bignerdranch.android.photogallery;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.HttpHeaderParser;

public abstract class XmlPullParsingRequest<T> extends Request<T> {
    private final Listener<T> mListener;
    
    public XmlPullParsingRequest(int method, String url, ErrorListener errorListener, Listener<T> listener) {
        super(method, url, errorListener);

        mListener = listener;
    }

    public abstract T parseXml(XmlPullParser parser) throws IOException, XmlPullParserException;

    @Override
    protected void deliverResponse(T response) {
        mListener.onResponse(response);
    }

    @Override
    protected Response<T> parseNetworkResponse(NetworkResponse response) {
        T parsed;
        String xmlText;

        try {
            xmlText = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
        } catch (UnsupportedEncodingException e) {
            xmlText = new String(response.data);
        }

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlText));
            parsed = parseXml(parser);
        } catch (IOException ioe) {
            return Response.error(new ParseError(ioe));
        } catch (XmlPullParserException xppe) {
            return Response.error(new ParseError(xppe));
        }

        return Response.success(parsed, HttpHeaderParser.parseCacheHeaders(response));
    }
}
