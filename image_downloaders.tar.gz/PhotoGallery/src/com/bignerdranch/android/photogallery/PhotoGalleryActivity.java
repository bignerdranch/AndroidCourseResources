package com.bignerdranch.android.photogallery;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;

public class PhotoGalleryActivity extends FragmentActivity {
    Class<?>[] mFragments;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpager);
        
        ViewPager pager = (ViewPager)findViewById(R.id.viewPager);
        FragmentManager fm = getSupportFragmentManager();
        
        mFragments = new Class<?>[]{
            PhotoGalleryFragment.class,
            Spacer.class,
            VollifiedFragment.class,
            Spacer.class,
            PicassoFragment.class
        };
        
        pager.setOnPageChangeListener(new OnPageChangeListener() {
            
            @Override
            public void onPageSelected(int pos) {
                setTitle(mFragments[pos].getSimpleName());
            }
            
            @Override
            public void onPageScrolled(int pos, float positionOffset, int positionOffsetPixels) {
            }
            
            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        
        pager.setAdapter(new FragmentStatePagerAdapter(fm) {
            @Override
            public int getCount() {
                return mFragments.length;
            }
            
            @Override
            public Fragment getItem(int pos) {
                try {
                    return (Fragment)mFragments[pos].newInstance();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        pager.setOffscreenPageLimit(0);
    }
}
